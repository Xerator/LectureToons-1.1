import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import CreatorPage from './pages/CreatorPage';
import Shop from './pages/Shop';
import AdminProfile from './pages/AdminProfile';
import { AuthProvider } from './contexts/AuthContext';

const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <main className="flex-grow">{children}</main>
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/creator/:id" element={<CreatorPage />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/admin" element={<AdminProfile />} />
          </Routes>
        </Layout>
      </Router>
    </AuthProvider>
  );
}