import React, { createContext, useContext, useState, useEffect } from 'react';
import Toast from '../components/Toast';

interface User {
  id: string;
  username: string;
  email: string;
  credits: number;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
  error: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showWelcomeToast, setShowWelcomeToast] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (email === 'test@example.com' && password === 'Test123!') {
        const user = {
          id: '1',
          username: 'TestUser',
          email: email,
          credits: 200 // Crédits de bienvenue
        };
        setUser(user);
        localStorage.setItem('user', JSON.stringify(user));
        setShowWelcomeToast(true);
      } else {
        throw new Error('Identifiants invalides');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue');
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (username: string, email: string, password: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user = {
        id: Date.now().toString(),
        username,
        email,
        credits: 200 // Crédits de bienvenue
      };
      setUser(user);
      localStorage.setItem('user', JSON.stringify(user));
      setShowWelcomeToast(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading, error }}>
      {children}
      <Toast
        message="🎉 Félicitations ! Vous avez reçu 200 crédits de bienvenue !"
        isVisible={showWelcomeToast}
        onClose={() => setShowWelcomeToast(false)}
      />
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}