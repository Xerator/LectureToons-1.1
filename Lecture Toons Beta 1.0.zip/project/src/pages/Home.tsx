import React from 'react';
import BannerSlider from '../components/BannerSlider';
import Features from '../components/Features';
import WebtoonGrid from '../components/WebtoonGrid';

export default function Home() {
  return (
    <main>
      <BannerSlider />
      <Features />
      
      {/* Daily Updates */}
      <div className="max-w-7xl mx-auto py-16">
        <div className="flex items-center justify-between px-4 mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Nouveautés du jour</h2>
          <div className="flex space-x-4 overflow-x-auto">
            {['LUN', 'MAR', 'MER', 'JEU', 'VEN', 'SAM', 'DIM'].map((day, index) => (
              <button
                key={day}
                className={`px-6 py-2 rounded-full transition-all ${
                  index === 0
                    ? 'bg-indigo-600 text-white shadow-indigo-200 shadow-lg'
                    : 'hover:bg-indigo-50 text-gray-600'
                }`}
              >
                {day}
              </button>
            ))}
          </div>
        </div>
        
        <WebtoonGrid />
      </div>
    </main>
  );
}