import React from 'react';
import { useParams } from 'react-router-dom';
import { Heart, Eye, Bell, Share2 } from 'lucide-react';

const creatorData = {
  "1": {
    name: "Sarah Miller",
    title: "Love 4 a Walk",
    cover: "https://images.unsplash.com/photo-1615494488088-43ac74d0c232?auto=format&fit=crop&w=800&q=80",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80",
    likes: "137 290",
    views: "1.2M",
    subscribers: "89.5K",
    description: "Une histoire d'amour moderne qui vous fera voyager à travers les rues de Paris.",
    genre: "Romance",
    chapters: 45,
    rating: 4.8
  }
};

export default function CreatorPage() {
  const { id } = useParams();
  const creator = creatorData[id as keyof typeof creatorData];

  if (!creator) return <div>Créateur non trouvé</div>;

  return (
    <div className="pt-16">
      {/* Cover Image */}
      <div className="h-64 w-full relative">
        <img
          src={creator.cover}
          alt="Cover"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
      </div>

      {/* Creator Info */}
      <div className="max-w-7xl mx-auto px-4 -mt-20 relative">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <img
              src={creator.avatar}
              alt={creator.name}
              className="w-24 h-24 rounded-full border-4 border-white shadow-lg"
            />
            
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900">{creator.title}</h1>
              <p className="text-lg text-gray-600 mt-1">par {creator.name}</p>
              
              <div className="flex flex-wrap gap-4 mt-4">
                <div className="flex items-center">
                  <Heart className="w-5 h-5 text-red-500 mr-2" />
                  <span className="text-gray-600">{creator.likes} likes</span>
                </div>
                <div className="flex items-center">
                  <Eye className="w-5 h-5 text-blue-500 mr-2" />
                  <span className="text-gray-600">{creator.views} vues</span>
                </div>
                <div className="flex items-center">
                  <Bell className="w-5 h-5 text-purple-500 mr-2" />
                  <span className="text-gray-600">{creator.subscribers} abonnés</span>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button className="btn btn-primary">
                <Bell className="w-5 h-5 mr-2" />
                S'abonner
              </button>
              <button className="btn btn-secondary">
                <Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="col-span-2">
              <h2 className="text-xl font-semibold mb-4">À propos</h2>
              <p className="text-gray-600">{creator.description}</p>
              
              <div className="mt-6 flex flex-wrap gap-4">
                <div className="bg-gray-100 px-4 py-2 rounded-full">
                  <span className="text-gray-600">{creator.genre}</span>
                </div>
                <div className="bg-gray-100 px-4 py-2 rounded-full">
                  <span className="text-gray-600">{creator.chapters} chapitres</span>
                </div>
                <div className="bg-gray-100 px-4 py-2 rounded-full">
                  <span className="text-gray-600">★ {creator.rating}</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-xl">
              <h3 className="text-lg font-semibold mb-4">Soutenir le créateur</h3>
              <div className="space-y-4">
                <button className="w-full btn btn-primary">
                  Acheter des crédits
                </button>
                <button className="w-full btn btn-secondary">
                  Envoyer un don
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}