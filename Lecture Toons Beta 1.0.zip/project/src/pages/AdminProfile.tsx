import React from 'react';
import { Shield, Users, BookOpen, Settings, BarChart2, AlertCircle } from 'lucide-react';

const stats = [
  { label: 'Utilisateurs actifs', value: '12,847', icon: Users, color: 'bg-blue-500' },
  { label: 'Webtoons publiés', value: '2,356', icon: BookOpen, color: 'bg-green-500' },
  { label: 'Signalements', value: '47', icon: AlertCircle, color: 'bg-red-500' },
  { label: 'Revenus du mois', value: '€8,942', icon: BarChart2, color: 'bg-purple-500' }
];

export default function AdminProfile() {
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-white/20 rounded-lg">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Administration</h1>
              <p className="text-indigo-100">Gérez votre plateforme LectureToons</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`${stat.color} p-3 rounded-lg text-white`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-sm font-medium text-gray-500">30j</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                <p className="text-gray-600">{stat.label}</p>
              </div>
            );
          })}
        </div>

        {/* Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <div className="col-span-2 bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-6">Actions rapides</h2>
            <div className="grid grid-cols-2 gap-4">
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <BookOpen className="w-6 h-6 text-indigo-600 mb-2" />
                <span className="text-sm font-medium">Valider les contenus</span>
              </button>
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <Users className="w-6 h-6 text-indigo-600 mb-2" />
                <span className="text-sm font-medium">Gérer les utilisateurs</span>
              </button>
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <AlertCircle className="w-6 h-6 text-indigo-600 mb-2" />
                <span className="text-sm font-medium">Voir les signalements</span>
              </button>
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <Settings className="w-6 h-6 text-indigo-600 mb-2" />
                <span className="text-sm font-medium">Paramètres</span>
              </button>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-6">Activité récente</h2>
            <div className="space-y-4">
              {[
                { text: 'Nouveau webtoon en attente de validation', time: 'Il y a 5min' },
                { text: 'Signalement de contenu inapproprié', time: 'Il y a 23min' },
                { text: 'Mise à jour des conditions d\'utilisation', time: 'Il y a 1h' },
                { text: '47 nouveaux utilisateurs aujourd\'hui', time: 'Il y a 2h' }
              ].map((activity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 rounded-full bg-indigo-600 mt-2" />
                  <div>
                    <p className="text-sm text-gray-600">{activity.text}</p>
                    <span className="text-xs text-gray-400">{activity.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}