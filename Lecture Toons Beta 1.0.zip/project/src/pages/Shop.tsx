import React from 'react';
import { CreditCard, Gift, Star } from 'lucide-react';

const creditPackages = [
  {
    credits: 100,
    price: "9.99€",
    popular: false,
    bonus: "0"
  },
  {
    credits: 500,
    price: "44.99€",
    popular: true,
    bonus: "+50 crédits bonus"
  },
  {
    credits: 1000,
    price: "84.99€",
    popular: false,
    bonus: "+150 crédits bonus"
  }
];

export default function Shop() {
  return (
    <div className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Boutique de Crédits</h1>
          <p className="text-xl text-gray-600">
            Soutenez vos créateurs préférés et débloquez du contenu exclusif
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {creditPackages.map((pkg, index) => (
            <div
              key={index}
              className={`relative rounded-2xl p-6 ${
                pkg.popular
                  ? 'bg-gradient-to-br from-indigo-600 to-purple-600 text-white shadow-xl'
                  : 'bg-white shadow-lg'
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-yellow-400 text-gray-900 px-4 py-1 rounded-full text-sm font-medium">
                  Plus populaire
                </div>
              )}

              <div className="flex items-center justify-center mb-6">
                <CreditCard className={`w-12 h-12 ${pkg.popular ? 'text-white' : 'text-indigo-600'}`} />
              </div>

              <div className="text-center mb-6">
                <h3 className={`text-2xl font-bold mb-2 ${pkg.popular ? 'text-white' : 'text-gray-900'}`}>
                  {pkg.credits} Crédits
                </h3>
                <p className={pkg.popular ? 'text-indigo-100' : 'text-gray-600'}>
                  {pkg.bonus}
                </p>
                <p className={`text-3xl font-bold mt-4 ${pkg.popular ? 'text-white' : 'text-gray-900'}`}>
                  {pkg.price}
                </p>
              </div>

              <button
                className={`w-full py-3 rounded-full font-medium transition-all ${
                  pkg.popular
                    ? 'bg-white text-indigo-600 hover:bg-gray-100'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                Acheter maintenant
              </button>
            </div>
          ))}
        </div>

        <div className="bg-gray-50 rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Comment utiliser vos crédits</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-start space-x-4">
              <div className="bg-indigo-100 p-3 rounded-lg">
                <Star className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Contenu Premium</h3>
                <p className="text-gray-600">Accédez à des chapitres en avant-première et du contenu exclusif</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="bg-indigo-100 p-3 rounded-lg">
                <Gift className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Soutenir les créateurs</h3>
                <p className="text-gray-600">Envoyez des dons à vos créateurs préférés</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="bg-indigo-100 p-3 rounded-lg">
                <CreditCard className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Achats in-app</h3>
                <p className="text-gray-600">Achetez des objets virtuels et des bonus exclusifs</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}