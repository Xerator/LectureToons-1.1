import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const banners = [
  {
    image: "/banner1.jpg",
    title: "Crystal Eyes",
    genre: "Action/Fantastique",
    description: "Des yeux qui brillent d'une lueur mystérieuse, cachant un pouvoir extraordinaire"
  },
  {
    image: "/banner2.jpg",
    title: "Blue Spirit",
    genre: "Action/Mystère",
    description: "Dans un monde où la magie et le chaos se rencontrent"
  },
  {
    image: "/banner3.jpg",
    title: "Dark Hunter",
    genre: "Action/Thriller",
    description: "Un regard perçant dans l'obscurité, prêt à tout pour la justice"
  },
  {
    image: "/banner4.jpg",
    title: "Mystic Eye",
    genre: "Action/Horreur",
    description: "Le pouvoir ultime se cache derrière ces yeux hypnotiques"
  }
];

export default function BannerSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAutoPlaying) {
      interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % banners.length);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % banners.length);
    setIsAutoPlaying(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + banners.length) % banners.length);
    setIsAutoPlaying(false);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
  };

  return (
    <div className="relative h-[500px] w-full overflow-hidden">
      <div 
        className="h-full transition-transform duration-700 ease-out flex"
        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
      >
        {banners.map((banner, index) => (
          <div
            key={index}
            className="h-full w-full flex-shrink-0 relative"
            style={{ left: `${index * 100}%`, position: 'absolute' }}
          >
            <img
              src={banner.image}
              alt={banner.title}
              className="w-full h-full object-cover"
            />
            
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <div className="max-w-7xl mx-auto">
                <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium mb-4 text-white">
                  {banner.genre}
                </span>
                <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white">{banner.title}</h2>
                <p className="text-lg text-white max-w-xl">{banner.description}</p>
                
                <button className="mt-6 px-8 py-3 bg-white text-gray-900 hover:bg-gray-100 rounded-full font-medium transition-colors">
                  Lire maintenant
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white transition-colors"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white transition-colors"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-3">
        {banners.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              currentSlide === index 
                ? 'bg-white scale-125' 
                : 'bg-white/50 hover:bg-white/75'
            }`}
          />
        ))}
      </div>
    </div>
  );
}