import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center">
              <span className="text-2xl font-bold">
                <span className="text-indigo-400">Lecture</span>
                <span className="text-purple-400">Toons</span>
              </span>
            </Link>
            <p className="text-sm text-gray-400">
              La meilleure plateforme de webtoons et romans en ligne. Découvrez des histoires uniques et passionnantes.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-purple-400 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-purple-400 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-purple-400 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-purple-400 transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="hover:text-purple-400 transition-colors">Accueil</Link>
              </li>
              <li>
                <Link to="/genres" className="hover:text-purple-400 transition-colors">Genres</Link>
              </li>
              <li>
                <Link to="/populaire" className="hover:text-purple-400 transition-colors">Populaire</Link>
              </li>
              <li>
                <Link to="/nouveautes" className="hover:text-purple-400 transition-colors">Nouveautés</Link>
              </li>
              <li>
                <Link to="/shop" className="hover:text-purple-400 transition-colors">Boutique</Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Support</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/aide" className="hover:text-purple-400 transition-colors">Centre d'aide</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-purple-400 transition-colors">Contact</Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-purple-400 transition-colors">FAQ</Link>
              </li>
              <li>
                <Link to="/conditions" className="hover:text-purple-400 transition-colors">Conditions d'utilisation</Link>
              </li>
              <li>
                <Link to="/confidentialite" className="hover:text-purple-400 transition-colors">Politique de confidentialité</Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Newsletter</h3>
            <p className="text-sm text-gray-400 mb-4">
              Restez informé des dernières sorties et actualités
            </p>
            <form className="space-y-2">
              <input
                type="email"
                placeholder="Votre email"
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-purple-400"
              />
              <button className="w-full px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:opacity-90 transition-opacity">
                S'abonner
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-gray-400">
              © 2024 LectureToons. Tous droits réservés.
            </p>
            <p className="text-sm text-gray-400 flex items-center">
              Fait avec <Heart className="w-4 h-4 text-red-500 mx-1" /> par l'équipe LectureToons
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}