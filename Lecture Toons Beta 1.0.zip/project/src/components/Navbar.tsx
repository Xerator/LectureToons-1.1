import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, User, Menu, ShoppingCart, LogOut } from 'lucide-react';
import AuthModal from './AuthModal';
import { useAuth } from '../contexts/AuthContext';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { user, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled ? 'bg-black/30 backdrop-blur-md' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center">
              <span className="text-2xl font-bold">
                <span className="text-white">Lecture</span>
                <span className="text-purple-400">Toons</span>
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/"
                className="text-white hover:text-purple-400 font-semibold transition-colors"
              >
                Découvrir
              </Link>
              <Link
                to="/"
                className="text-white hover:text-purple-400 font-semibold transition-colors"
              >
                Genres
              </Link>
              <Link
                to="/"
                className="text-white hover:text-purple-400 font-semibold transition-colors"
              >
                Populaire
              </Link>
              <Link
                to="/"
                className="text-white hover:text-purple-400 font-semibold transition-colors"
              >
                Romans
              </Link>
              <Link
                to="/shop"
                className="text-white hover:text-purple-400 font-semibold transition-colors flex items-center"
              >
                <ShoppingCart className="w-5 h-5 mr-1" />
                <span>Boutique</span>
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <button className="text-white hover:text-purple-400 transition-colors">
                <Search className="w-5 h-5" />
              </button>
              <button className="hidden md:flex items-center space-x-2 bg-purple-600 text-white px-6 py-2 rounded-full hover:bg-purple-700 transition-colors">
                <span>Créer</span>
              </button>
              
              {user ? (
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                    <span className="text-white font-medium">{user.username}</span>
                    <div className="h-4 w-px bg-white/20" />
                    <span className="text-purple-300 font-medium">{user.credits} crédits</span>
                  </div>
                  <button
                    onClick={logout}
                    className="flex items-center space-x-2 text-white hover:text-purple-400 transition-colors bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="hidden md:inline">Déconnexion</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="flex items-center space-x-2 text-white hover:text-purple-400 transition-colors"
                >
                  <User className="w-5 h-5" />
                  <span className="hidden md:inline">Mon compte</span>
                </button>
              )}
              
              <button className="md:hidden text-white">
                <Menu className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </>
  );
}