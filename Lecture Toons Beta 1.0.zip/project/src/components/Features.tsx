import React from 'react';
import { BookOpen, Palette, Users, Sparkles, BookMarked, Zap } from 'lucide-react';

const features = [
  {
    icon: BookOpen,
    title: "Lecture fluide",
    description: "Interface optimisée pour une expérience de lecture immersive"
  },
  {
    icon: Palette,
    title: "Outils créatifs",
    description: "Suite complète d'outils pour les créateurs de contenu"
  },
  {
    icon: Users,
    title: "Communauté active",
    description: "Échangez avec d'autres passionnés de webtoons"
  },
  {
    icon: Sparkles,
    title: "IA personnalisée",
    description: "Recommandations intelligentes basées sur vos préférences"
  },
  {
    icon: BookMarked,
    title: "Bibliothèque personnelle",
    description: "Organisez et suivez vos lectures favorites"
  },
  {
    icon: Zap,
    title: "Mises à jour rapides",
    description: "Notifications instantanées pour vos séries suivies"
  }
];

export default function Features() {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Une expérience de lecture unique
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Découvrez pourquoi LectureToons est la plateforme préférée des lecteurs et créateurs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="p-6 bg-gray-50 rounded-2xl hover:bg-indigo-50 transition">
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4">
                  <Icon className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}