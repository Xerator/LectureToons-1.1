import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-gradient-to-b from-indigo-50 to-white pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Découvrez l'univers des
            <span className="text-indigo-600"> webtoons</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Plongez dans un monde d'histoires captivantes. Lisez, créez et partagez des webtoons et romans avec une communauté passionnée.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="flex items-center justify-center space-x-2 bg-indigo-600 text-white px-8 py-3 rounded-full hover:bg-indigo-700 transform transition">
              <span>Commencer la lecture</span>
              <ArrowRight className="h-5 w-5" />
            </button>
            <button className="flex items-center justify-center space-x-2 bg-white text-indigo-600 px-8 py-3 rounded-full border-2 border-indigo-600 hover:bg-indigo-50">
              <Sparkles className="h-5 w-5" />
              <span>Devenir créateur</span>
            </button>
          </div>
        </div>
        
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-2xl shadow-lg transform hover:-translate-y-1 transition">
            <img
              src="https://images.unsplash.com/photo-1611604548018-d56bbd85d681?auto=format&fit=crop&w=800&q=80"
              alt="Webtoon Preview"
              className="w-full h-48 object-cover rounded-lg mb-4"
            />
            <h3 className="text-lg font-semibold mb-2">Nouveautés</h3>
            <p className="text-gray-600">Découvrez les dernières créations de nos artistes talentueux.</p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-lg transform hover:-translate-y-1 transition">
            <img
              src="https://images.unsplash.com/photo-1615494488088-43ac74d0c232?auto=format&fit=crop&w=800&q=80"
              alt="Novel Preview"
              className="w-full h-48 object-cover rounded-lg mb-4"
            />
            <h3 className="text-lg font-semibold mb-2">Romans populaires</h3>
            <p className="text-gray-600">Les meilleures histoires sélectionnées pour vous.</p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-lg transform hover:-translate-y-1 transition">
            <img
              src="https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80"
              alt="Creator Preview"
              className="w-full h-48 object-cover rounded-lg mb-4"
            />
            <h3 className="text-lg font-semibold mb-2">Espace créateur</h3>
            <p className="text-gray-600">Partagez vos œuvres avec le monde entier.</p>
          </div>
        </div>
      </div>
    </div>
  );
}