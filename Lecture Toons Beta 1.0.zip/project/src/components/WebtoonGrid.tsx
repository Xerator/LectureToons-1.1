import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, Eye } from 'lucide-react';

const webtoons = [
  {
    id: "1",
    title: "Je suis partie de zero et j'ai atteint le niveau 100",
    creator: "Sarah Miller",
    cover: "https://images.unsplash.com/photo-1615494488088-43ac74d0c232?auto=format&fit=crop&w=800&q=80",
    likes: "137 290",
    views: "1.2M",
    genre: "Action",
    isUpdated: true,
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.",
    releaseDay: "Tout les vendredi"
  },
  {
    id: "2",
    title: "Amour égoïste",
    creator: "Jean Dupont",
    cover: "https://images.unsplash.com/photo-1579547621869-0ddb5f237392?auto=format&fit=crop&w=800&q=80",
    likes: "105 067",
    views: "890K",
    genre: "Romance",
    isUpdated: true
  },
  {
    id: "3",
    title: "Tu es à croquer",
    creator: "Marie Laurent",
    cover: "https://images.unsplash.com/photo-1611604548018-d56bbd85d681?auto=format&fit=crop&w=800&q=80",
    likes: "496 526",
    views: "2.1M",
    genre: "Romance",
    isUpdated: true
  },
  {
    id: "4",
    title: "Le Bébé Tyran",
    creator: "Alex Chen",
    cover: "https://images.unsplash.com/photo-1612436395449-08efb9444219?auto=format&fit=crop&w=800&q=80",
    likes: "745 707",
    views: "3.5M",
    genre: "Fantastique",
    isUpdated: true
  }
];

export default function WebtoonGrid() {
  const navigate = useNavigate();

  const handleWebtoonClick = (id: string) => {
    navigate(`/creator/${id}`);
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 px-4">
      {webtoons.map((webtoon) => (
        <div 
          key={webtoon.id} 
          className="relative group cursor-pointer"
          onClick={() => handleWebtoonClick(webtoon.id)}
        >
          <div className="aspect-[3/4] overflow-hidden rounded-lg">
            <img
              src={webtoon.cover}
              alt={webtoon.title}
              className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
            />
          </div>
          {webtoon.isUpdated && (
            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
              UP
            </div>
          )}
          <div className="mt-2">
            <h3 className="font-semibold text-gray-900 hover:text-indigo-600 truncate">
              {webtoon.title}
            </h3>
            <p className="text-sm text-gray-500">{webtoon.creator}</p>
            <div className="flex items-center text-sm text-gray-500 mt-1">
              <span className="bg-gray-100 px-2 py-0.5 rounded-full text-xs">
                {webtoon.genre}
              </span>
              <div className="flex items-center ml-2">
                <Heart className="w-3 h-3 text-red-500 mr-1" />
                <span className="text-xs">{webtoon.likes}</span>
              </div>
              <div className="flex items-center ml-2">
                <Eye className="w-3 h-3 text-blue-500 mr-1" />
                <span className="text-xs">{webtoon.views}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}